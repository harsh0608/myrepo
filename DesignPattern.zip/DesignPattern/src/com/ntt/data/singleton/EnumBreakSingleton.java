package com.ntt.data.singleton;

public enum EnumBreakSingleton {

	INTANCE;
	
	
}
