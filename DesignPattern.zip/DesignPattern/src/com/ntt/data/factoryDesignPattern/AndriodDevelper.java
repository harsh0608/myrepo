package com.ntt.data.factoryDesignPattern;

public class AndriodDevelper implements Employee{

	
	public int salary() {
		System.out.println("Salary of AndriodDevelper");
		return 50000;
	}

}
