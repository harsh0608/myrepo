package com.ntt.data.behave.observerDesignPattern;

public class Subscriber implements Observer{

	@Override
	public void notified(String gaana) {
		System.out.println("Hi Subscriber new song is uploaded check and hit the like button gaana name is :"+gaana );
		
	}

}
