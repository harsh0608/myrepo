package com.ntt.data.behave.observerDesignPattern;

import java.util.ArrayList;
import java.util.List;

public class YoutubeChannal implements Subject{
	
	List<Observer> subcriber = new ArrayList<>();

	@Override
	public void subscribe(Observer obs) {
		this.subcriber.add(obs);
		
	}

	@Override
	public void unsubscribe(Observer obs) {
		this.subcriber.remove(obs);
		  
	}

	@Override
	public void notifyChanges(String gaana) {
		for(Observer ob : this.subcriber) {
			ob.notified(gaana);
		}
		
	}

	
}
