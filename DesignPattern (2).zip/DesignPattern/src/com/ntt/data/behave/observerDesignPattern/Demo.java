package com.ntt.data.behave.observerDesignPattern;

public class Demo {

	public static void main(String[] args) {

    YoutubeChannal youtubeChannal = new YoutubeChannal();
    
    Subscriber subscriber = new Subscriber();
    
    youtubeChannal.subscribe(subscriber);
    
    youtubeChannal.notifyChanges("Ram aayega");
    
	}

}
