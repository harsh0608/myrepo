package com.ntt.data.behave.observerDesignPattern;

public interface Observer {

	
	void notified(String gaana);
}
