package com.ntt.data.Creational.protoTypeDesignPattern;

import java.util.ArrayList;
import java.util.List;

public class NetworkConnection implements Cloneable{

	private String ip;
	private String impData;
	
	List<String> domain = new ArrayList<String>();
	
	
	
	public List<String> getDomain() {
		return domain;
	}
	public void setDomain(List<String> domain) {
		this.domain = domain;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getImpData() {
		return impData;
	}
	public void setImpData(String impData) {
		this.impData = impData;
	}
	
	
	public void loadVeryImpData() throws InterruptedException {
		this.impData = "very very imp data load";
		domain.add("www.google.com");
		domain.add("www.fb.com");
		domain.add("www.systemDesign.com");
		domain.add("www.java.com");
	//	Thread.sleep(5000);
		
	}
	
	@Override
	public String toString() {
		return this.ip+" : "+this.impData+" : "+this.domain;	
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		
		//logic for deep cloning
		NetworkConnection networkConnection = new NetworkConnection();
		networkConnection.setImpData(this.getImpData());
		networkConnection.setIp(this.getIp());
		
		for(String d :this.getDomain()) {
			networkConnection.getDomain().add(d);
		}
		
	//	return super.clone();   // this return give two defferent obj
		return networkConnection;
		
		}	
}
