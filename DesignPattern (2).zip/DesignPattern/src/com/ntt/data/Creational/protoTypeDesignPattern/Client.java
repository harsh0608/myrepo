package com.ntt.data.Creational.protoTypeDesignPattern;

public class Client {

	
	/**
	 * Concept of copy the existing object rather then creating a new instance from scratch. because creating new object 
	 * may be costly. this approach save costly resource and time , especially when object creation is heavy process.
	 * example - database connection , at the object creation we read hug file , or network connection at the time of object creation
	 * @throws CloneNotSupportedException 
	 * 
	 * 
	 * two type of copy 
	 * shallow copy means if you copy any object1 and object1 contain other object2 so if you changes anything in object2 using ref of object1
	 * then all changes reflact in copy object two
	 * deep copy - when do some logic in clone class that we can prevent changes of internal obj
	 * 
	 */
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("demo of prototype design pattern");
		
		NetworkConnection networkConnection = new NetworkConnection();
		networkConnection.setIp("10.15.20.119");
		networkConnection.loadVeryImpData();
		System.out.println(networkConnection);

		NetworkConnection networkConnection1 = (NetworkConnection) networkConnection.clone();
		NetworkConnection networkConnection2 = (NetworkConnection) networkConnection.clone();
		NetworkConnection networkConnection3 = (NetworkConnection) networkConnection.clone();
		
		
		networkConnection.getDomain().remove(0);
		
		System.out.println(networkConnection);
		System.out.println(networkConnection1);
		System.out.println(networkConnection2);
		System.out.println(networkConnection3);
		
		
		
	}


	
}
