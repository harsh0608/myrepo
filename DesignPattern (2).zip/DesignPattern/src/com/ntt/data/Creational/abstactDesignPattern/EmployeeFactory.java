package com.ntt.data.Creational.abstactDesignPattern;

public class EmployeeFactory {

	public static Employee getEmployee(EmpAbstactFactory factory) {
		
		return factory.createEmployee();
	}
}
