package com.ntt.data.Creational.abstactDesignPattern;

public interface Employee {

	int salary();
	
	String name();
	
}
