package com.ntt.data.Creational.abstactDesignPattern;

public class Client {

	public static void main(String[] args) {


		
	Employee emp1 = EmployeeFactory.getEmployee(new AndoridFactory());
	System.out.println(emp1.salary());
	System.out.println(emp1.name());
	
	Employee emp2 = EmployeeFactory.getEmployee(new JavaFactory());
	System.out.println(emp2.salary());
	System.out.println(emp2.name());
	
	Employee emp3 = EmployeeFactory.getEmployee(new DesignFactory());
	System.out.println(emp3.salary());
	System.out.println(emp3.name());
	
	}

}
