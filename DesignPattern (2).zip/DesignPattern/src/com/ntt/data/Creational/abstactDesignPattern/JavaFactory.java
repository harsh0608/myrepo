package com.ntt.data.Creational.abstactDesignPattern;

public class JavaFactory extends EmpAbstactFactory{

	@Override
	public Employee createEmployee() {
		// TODO Auto-generated method stub
		return new JavaDevelper();
	}

}
