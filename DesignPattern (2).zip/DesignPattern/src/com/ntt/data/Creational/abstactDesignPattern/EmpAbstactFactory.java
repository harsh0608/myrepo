package com.ntt.data.Creational.abstactDesignPattern;

abstract public class EmpAbstactFactory {

	public abstract Employee createEmployee();
}
