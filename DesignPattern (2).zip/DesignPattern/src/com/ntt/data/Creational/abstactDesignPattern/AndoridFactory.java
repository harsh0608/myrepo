package com.ntt.data.Creational.abstactDesignPattern;

public class AndoridFactory extends EmpAbstactFactory{

	@Override
	public Employee createEmployee() {
		
		return new AndoridDeveloper();
	}

}
