package com.ntt.data.Creational.abstactDesignPattern;

public class JavaDevelper implements Employee{

	
	@Override
	public int salary() {
		// TODO Auto-generated method stub
		return 100000;
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		System.out.println("I am Java dev");
		return "JavaDevelper";
	}
}
