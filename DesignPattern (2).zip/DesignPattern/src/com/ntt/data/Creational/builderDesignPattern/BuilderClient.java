package com.ntt.data.Creational.builderDesignPattern;

import com.ntt.data.Creational.builderDesignPattern.URL.URLBuilder;

public class BuilderClient {

	
	/*
	 *  use- creating complex object
	 *  help with immuatable class(Define object which once created never change thire value)
	 *  less need for exposing setters
	 *  in factory design pattern we don't know how many const or object we need to create (example - almira)
	 *  usability - Stringbuilder is the builder class which helps you to concatenate string one after the other and finally 
	 *  return a string which you cann't change
	 * 
	 *  URL builder - Used to create URL objects given some params
	 * 
	 *   http://www.nttdatacom:8080/companies?companyName=xyz
	 *   protocal!    HostName  !port! path param! Query Param
	 *   in above example - Protocol and hostName is mandatory
	 *   but port and path param , Query Param not mandatory
	 *   
	 *   
	 *   Implement builder class we need to create inner static class
	 *   
	 *   
	 */
	
		 public static void main(String[] args) {
//		 URL url = new URL();
//		 url.setProtocal("http:");
//		 url.setHostname("//www.nttdatacom:");
//		 url.setPort("8080/");
//		 url.setPathParam("companies");
//		 
//		 
//		 System.out.print(url.getProtocal());
//		 System.out.print(url.getHostname());
//		 System.out.print(url.getPort());
//		 System.out.print(url.getPathParam());
			 
		URL url = new URL.URLBuilder()
			 .setProtocal("http://")
	 		 .setHostname("www.nttdatacom:")
			 .setPort("8080")
			 .setPathParam("/companies")
			 .build();      //.build method imp otherwise we need to store new URL.URLBuilder() object to URLBuilder
		 
		System.out.println(url.toString());
		
		
		}
}
