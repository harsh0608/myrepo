package com.ntt.data.Creational.builderDesignPattern;

public class URL {

	private String protocal;
	private String hostname;
	private String port;
	private String pathParam;
	private String queryParam;
	
	//here we are using URLBUilder in URL class
	public URL(URLBuilder urlBuilder) {

		this.protocal = urlBuilder.protocal;
		this.hostname = urlBuilder.hostname;
		this.port = urlBuilder.port;
		this.pathParam = urlBuilder.pathParam;
		this.queryParam = urlBuilder.queryParam;

	}
	
	
	@Override
	public String toString() {
		return "URL [protocal=" + protocal + ", hostname=" + hostname + ", port=" + port + ", pathParam=" + pathParam
				+ ", queryParam=" + queryParam + "]";
	}


	public URL(String protocal) {
		super();
		this.protocal = protocal;
	}
	
	public URL(String protocal, String hostname) {
		super();
		this.protocal = protocal;
		this.hostname = hostname;
	}
	
	public URL(String protocal, String hostname, String port, String pathParam, String queryParam) {
		super();
		this.protocal = protocal;
		this.hostname = hostname;
		this.port = port;
		this.pathParam = pathParam;
		this.queryParam = queryParam;
	}

	public String getProtocal() {
		return protocal;
	}


	public String getHostname() {
		return hostname;
	}


	public String getPort() {
		return port;
	}


	public String getPathParam() {
		return pathParam;
	}


	public String getQueryParam() {
		return queryParam;
	}


	
	
	static class URLBuilder{
		
		private String protocal;
		private String hostname;
		private String port;
		private String pathParam;
		private String queryParam;
		
		
		public URLBuilder() {
			
		}
		// this is call method chaining
		
		public URLBuilder setProtocal(String protocal) {
			this.protocal = protocal;
			return this;
		}


		public URLBuilder setHostname(String hostname) {
			this.hostname = hostname;
			return this;
		}


		public URLBuilder setPort(String port) {
			this.port = port;
			return this;
		}


		public URLBuilder setPathParam(String pathParam) {
			this.pathParam = pathParam;
			return this;
		}

		public URLBuilder setQueryParam(String queryParam) {
			this.queryParam = queryParam;
			return this;
		}
		
		public URL build() {
			URL url = new URL(this);
			return url;
		}
	}
	
}
