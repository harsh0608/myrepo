package com.ntt.data.Creational.singletonDesignPattern;

import java.io.Serializable;

public class School implements Serializable, Cloneable{

	
	//singleton design pattern : create object onces and use through out the project
    //so basic logic is that we need to prevent creation of multiple object
	
	/*
	 * 1) create private const not public becouse using public const we need to create mutiple object
	 * 2) object create with the help of method (getschool)
	 * 3) create field to store private variable
	 */
	
	private static School school;
	
	private School() { 
		
		if(school !=null) {
			throw new RuntimeException("you are try to break singlton design pattern");
		}
	}
	
	//lazy way of creating singleton object (means whenever client wants the object then hit the method then onlye object will be created)
//	public  static School getSchool() {
//		//this method create the object of this method 
//	    //School school = new School(); //this line we don't use if anyone class 4 time in this method so object create 4 time
//		if(school ==null) {
//			school = new School();	
//		}
//		return school;
//	}
	
	//eger way of creating singleton object
 //	private static School school1= new School();
 //public static School getegerSchool() {
	//	return school1;
	//}
	
	
/* all above example are use on in single thread env
 * for multi thread we need to use syncroniced
 * 
 */
	
	//below we use mathod synchronized but we don't need method scy we need to synco only one line so we use mynco block
//	public synchronized static School getSchool() {  
//		//this method create the object of this method 
//	    //School school = new School(); //this line we don't use if anyone class 4 time in this method so object create 4 time
//		if(school ==null) {
//			school = new School();	
//		}
//		return school;
//	}
//	
	public static School getSchool() {  
		//this method create the object of this method 
	    //School school = new School(); //this line we don't use if anyone class 4 time in this method so object create 4 time
		if(school ==null) {	
			synchronized (School.class) {
				if(school ==null) {
				school = new School();
				}
			}		
		}
		return school;
	}
	
	public Object readResolve() {
		return getSchool();
	}
	
	protected Object clone() throws CloneNotSupportedException {
	//	return super.clone();   // this return give two defferent obj
		return getSchool();  //this return give one obj
	}
 
}
