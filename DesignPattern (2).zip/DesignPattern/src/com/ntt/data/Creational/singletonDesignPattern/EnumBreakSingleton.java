package com.ntt.data.Creational.singletonDesignPattern;

public enum EnumBreakSingleton {

	INTANCE;
	
	
}
