package com.ntt.data.Creational.singletonDesignPattern;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;



public class Example {

	public static void main(String[] args) throws Exception{
		//for lazy loading
//		School school = School.getSchool();
//		System.out.println(school.hashCode());
//		
//		School school1 = School.getSchool();
//		System.out.println(school1.hashCode());
		
	//	for eger way tite cupling
//		School school1 = School.getegerSchool();
//		System.out.println(school1.hashCode());
//		
//		School school2 = School.getegerSchool();
//		System.out.println(school2.hashCode());
		
		
		/*
		 * how we break singleton design pattern
		 * 1) Reflacation API : to break singleton pattern
		 * sol: 1)if object already present there then throw exception, from inside constructor
		 *  2) use enum
		 * 
		 * 3) Deserializable 
		 * sol : 1) implement readResolverber method
		 * 
		 * 4) clone method
		 * sol : 1) 
		 * 
		 * real time use in logger and jdbc connectivity and chaching when ever single point of access
		 * 
		 */

		//1 reflaction
//		School school1 = School.getSchool();
//		System.out.println(school1.hashCode());
////		
//		Constructor<School> construtor = School.class.getDeclaredConstructor();
//		construtor.setAccessible(true);
//		School scholl2 = construtor.newInstance();
//		System.out.println(scholl2.hashCode());
//		
		//2. enum
		// use enum 
		
//		EnumBreakSingleton enumBreakSingleton = EnumBreakSingleton.INTANCE;
//		EnumBreakSingleton enumBreakSingleton1 = EnumBreakSingleton.INTANCE;
//		System.out.println(enumBreakSingleton.hashCode());
//		System.out.println(enumBreakSingleton1.hashCode());
		
//		Constructor<EnumBreakSingleton> construtor = EnumBreakSingleton.class.getDeclaredConstructor();
//		EnumBreakSingleton.setAccessible(true);
//		School scholl2 = EnumBreakSingleton.newInstance();
//		System.out.println(scholl2.hashCode());
		
		//3. serialization and Deserialization
//		School school  = School.getSchool();
//		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("abc.ob"));   // use this line for serialization
//		oos.writeObject(school);
//		System.out.println("serialization done....");
//////		
//		ObjectInputStream oon = new ObjectInputStream(new FileInputStream("abc.ob"));
//		School school2 = (School) oon.readObject();
//		
//		System.out.println("Serializable " +school.hashCode());
//		System.out.println("Deserialzable " +school2.hashCode());
////		
		// above example of break singleton design using serialization and deserializble 
		// I am not able to protected singleton
		
		// 4 )  use clone method to break singleton design pattern
//		 School school  = School.getSchool();
//		System.out.println(school.hashCode());
//		School school1 = (School) school.clone();
//		System.out.println(school1.hashCode());
//		

		
		
		

	}

}
