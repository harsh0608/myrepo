
package com.ntt.data.Creational.factoryDesignPattern;

public class Example {

	public static void main(String[] args) {
		
//		Employee andemp = new AndriodDevelper();
//		System.out.println(andemp.salary());
//		
//		Employee dotemp = new DotNetDeveloper();
//		System.out.println(dotemp.salary());
//		
//		Employee javaemp = new JavaDevleoper();
//		System.out.println(javaemp.salary());

		
		//above method is not the good method we can't insist the client to create the class
		
		
		/*
		 * use : hinding complex logic of object creation
		 * 2)Parsing various data formats (like json ,xml,CSV) 
		 * 3) in facebook when use upload video audio and text data that time we use factory design pattern
		 * 
		 * 
		 * 
		 */
		
		Employee employee = EmployeeFactory.empFactory("Andriod Developer");
		System.out.println(employee.salary());
		
	}

}
