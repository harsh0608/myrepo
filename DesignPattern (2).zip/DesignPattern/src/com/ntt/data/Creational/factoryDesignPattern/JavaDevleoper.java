package com.ntt.data.Creational.factoryDesignPattern;

public class JavaDevleoper implements Employee{

	
	public int salary() {
		System.out.println("Salary of JavaDevelper");
		return 100000;
	}
}
