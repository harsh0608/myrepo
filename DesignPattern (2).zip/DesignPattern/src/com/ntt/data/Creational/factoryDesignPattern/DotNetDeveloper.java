package com.ntt.data.Creational.factoryDesignPattern;

public class DotNetDeveloper implements Employee{
	
	
	public int salary() {
		System.out.println("Salary of DotNetDevelper");
		return 30000;
	}

}
