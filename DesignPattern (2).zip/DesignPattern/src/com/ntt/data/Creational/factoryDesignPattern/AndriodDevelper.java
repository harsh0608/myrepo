package com.ntt.data.Creational.factoryDesignPattern;

public class AndriodDevelper implements Employee{



	
	public int salary() {
		System.out.println("Salary of AndriodDevelper");
		return 50000;
	}
	
	

	

}
