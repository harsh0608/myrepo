package com.ntt.data.Creational.factoryDesignPattern;

public class EmployeeFactory {

	
	public static Employee empFactory(String emptype) {
		
		if(emptype.trim().equalsIgnoreCase("Andriod Developer")) {
			Employee  andriodEmployee = new AndriodDevelper();
			return andriodEmployee;
		}if(emptype.trim().equalsIgnoreCase("DotNet Developer")) {
			Employee  dotNetEmployee = new DotNetDeveloper();
			return dotNetEmployee;
		}if(emptype.trim().equalsIgnoreCase("java Developer")) {
			Employee  javaEmployee = new JavaDevleoper();
			return javaEmployee;
		}else {
			return null;
		}			
	}
}
