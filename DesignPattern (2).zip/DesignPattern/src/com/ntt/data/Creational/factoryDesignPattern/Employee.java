package com.ntt.data.Creational.factoryDesignPattern;

public interface Employee {

	/*
	 * Factory Design pattern : there is one supper class and multiple subclass we wants to get object of sub class based on 
	 * input and requirements
	 * then we can the factory class who take the responsibility of creating object based on input
	 * 
	 * Advan :
	 * loss cupling, more rubas code
	 * focus on creating the object for interface rather then implementation
	 * bin validation
	 * surchnages service
	 * 
	 * 
	 */
	
	int salary();
	
	
}
